#ifndef _ORDENADORSELECT_
#define _ORDENADORSELECT_

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void selectionSort(int*, int);

#endif
