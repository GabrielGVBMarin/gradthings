#ifndef _INSERTION_
#define _INSERTION_

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void insertionSort(int*, int);

#endif
