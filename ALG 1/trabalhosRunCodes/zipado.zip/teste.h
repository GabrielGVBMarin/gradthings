#ifndef _H_TESTE
#define _H_TESTE

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// declaracao da func
void DCTII(double*, double*, int);

#endif
